# قائمة مهام تطوير موقع "عطورنا"

## المرحلة 1: الإعداد والأساسيات

- [X] 1.1. اختيار وتثبيت التقنيات النهائية (Node.js/Express, React.js, PostgreSQL).
- [X] 1.2. إعداد هيكل المشروع (Backend & Frontend).
- [X] 1.3. تصميم وتنفيذ مخطط قاعدة البيانات (PostgreSQL).
- [X] 1.4. إعداد الاتصال بقاعدة البيانات.
- [X] 1.5. إعداد بيئة التطوير (Development Environment).

## المرحلة 2: تطوير الواجهة الخلفية (Backend - Node.js/Express)

- [X] 2.1. بناء نظام التوجيه (Routing) الأساسي.
- [X] 2.2. تطوير وحدة المنتجات (API Endpoints: CRUD, List, Filter, Search).
- [X] 2.3. تطوير وحدة الفئات (API Endpoints: CRUD, List).
- [X] 2.4. تطوير وحدة المستخدمين (API Endpoints: Register, Login, Get Profile, Update Profile).
- [X] 2.5. تطبيق آليات المصادقة والتفويض (JWT أو ما شابه).
- [X] 2.6. تطوير وحدة الطلبات (API Endpoints: Create Order - COD only, Get User Orders, Get All Orders (Admin), Update Order Status (Admin)).
- [X] 2.7. تطوير وحدة الطلبات الخاصة (API Endpoints: Submit Special Order, Get Special Orders (Admin)).
- [X] 2.8. تطبيق إجراءات الأمان الأساسية (Input Validation, Password Hashing, Helmet.js, CORS).
- [X] 2.9. إعداد وحدة إرسال البريد الإلكتروني (لتأكيد الطلبات، إلخ).
- [ ] 2.10. بناء واجهات برمجة التطبيقات للوحة التحكم الإدارية (Admin Panel APIs).

## المرحلة 3: تطوير الواجهة الأمامية (Frontend - React.js)

- [X] 3.1. إعداد مشروع React (Vite أو Create React App).
- [X] 3.2. تثبيت وإعداد مكتبات الواجهة (Tailwind CSS أو Material UI).
- [X] 3.3. إعداد إدارة الحالة (State Management - Redux/Zustand).
- [X] 3.4. بناء المكونات الأساسية (Header, Footer, Layout).
- [X] 3.5. بناء صفحة الرئيسية (Home Page).
- [X] 3.6. بناء صفحات عرض المنتجات (Product Listing Pages) مع الفلترة والتصنيف.
- [X] 3.7. بناء صفحة تفاصيل المنتج (Product Detail Page).
- [X] 3.8. بناء صفحة سلة التسوق (Cart Page).
- [X] 3.9. بناء صفحة الدفع (Checkout Page - COD only).
- [X] 3.10. بناء صفحة تأكيد الطلب (Order Confirmation Page).
- [X] 3.11. بناء صفحات حساب المستخدم (Profile, Orders).
- [X] 3.12. بناء صفحة الطلبات الخاصة (Special Order Form).
- [X] 3.13. بناء الصفحات الثابتة (About, Contact, Privacy, Terms).
- [X] 3.14. دمج الواجهات البرمجية (API Integration) لجميع الوحدات.
- [X] 3.15. تطبيق التصميم المتجاوب (Responsive Design).
- [X] 3.16. تطبيق دعم اللغتين (Internationalization - i18n) العربية (افتراضي) والإنجليزية.
- [ ] 3.17. بناء واجهة لوحة التحكم الإدارية (Admin Panel UI).

## المرحلة 4: المحتوى والاختبار والنشر

- [X] 4.1. إضافة محتوى مبدئي للمنتجات (صور وأوصاف لـ 30 مل، تركيز 40%).
- [X] 4.3. إجراء اختبارات التكامل (Integration Tests).
- [X] 4.4. إجراء اختبارات الواجهة الأمامية (Component/E2E Tests - اختياري).
- [X] 4.5. اختبار الأمان الشامل (Security Testing).
- [X] 4.6. اختبار قابلية الاستخدام (Usability Testing) والتجاوب عبر الأجهزة.
- [X] 4.7. التحقق من دقة البيانات والوظائف.
- [ ] 4.8. البحث عن اسم نطاق "otorona" واقتراح خيارات استضافة.
- [ ] 4.9. إعداد بيئة الإنتاج (Production Environment).
- [ ] 4.10. نشر النسخة الأولية للموقع (Deployment).
- [ ] 4.11. تسليم الموقع والوثائق للمستخدم.

