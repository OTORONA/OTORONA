// Placeholder for Order Controller Logic
const db = require("../db");

// Create a new order (COD only)
exports.createOrder = async (req, res) => {
    const userId = req.user?.userId; // Optional: Get user ID if logged in
    const { items, shipping_address, billing_address } = req.body;

    // Basic validation
    if (!items || items.length === 0 || !shipping_address) {
        return res.status(400).json({ message: "Items and shipping address are required" });
    }

    const client = await db.pool.connect(); // Use transaction

    try {
        await client.query("BEGIN");

        // 1. Calculate total amount and check stock
        let totalAmount = 0;
        const productDetails = [];
        for (const item of items) {
            const { rows } = await client.query("SELECT price, stock_quantity FROM products WHERE id = $1", [item.product_id]);
            if (rows.length === 0) {
                throw new Error(`Product with ID ${item.product_id} not found.`);
            }
            const product = rows[0];
            if (product.stock_quantity < item.quantity) {
                throw new Error(`Insufficient stock for product ID ${item.product_id}. Available: ${product.stock_quantity}, Requested: ${item.quantity}`);
            }
            const itemTotal = product.price * item.quantity;
            totalAmount += itemTotal;
            productDetails.push({ ...item, price_at_purchase: product.price });
        }

        // 2. Create the order
        const orderQuery = `
            INSERT INTO orders (user_id, total_amount, shipping_address, billing_address, payment_method, status)
            VALUES ($1, $2, $3, $4, 'COD', 'pending') RETURNING id, created_at;
        `;
        const orderValues = [userId, totalAmount, shipping_address, billing_address || shipping_address];
        const orderResult = await client.query(orderQuery, orderValues);
        const orderId = orderResult.rows[0].id;
        const orderCreatedAt = orderResult.rows[0].created_at;

        // 3. Create order items and update stock
        const itemInsertQuery = "INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES ($1, $2, $3, $4)";
        const stockUpdateQuery = "UPDATE products SET stock_quantity = stock_quantity - $1 WHERE id = $2";

        for (const detail of productDetails) {
            await client.query(itemInsertQuery, [orderId, detail.product_id, detail.quantity, detail.price_at_purchase]);
            await client.query(stockUpdateQuery, [detail.quantity, detail.product_id]);
        }

        await client.query("COMMIT");

        // TODO: Send confirmation email

        res.status(201).json({ 
            message: "Order created successfully", 
            orderId: orderId, 
            totalAmount: totalAmount,
            createdAt: orderCreatedAt
        });

    } catch (error) {
        await client.query("ROLLBACK");
        console.error("Error creating order:", error);
        res.status(500).json({ message: error.message || "Error creating order" }); // Send specific error message if available
    } finally {
        client.release();
    }
};

// Get orders for the logged-in user
exports.getUserOrders = async (req, res) => {
    const userId = req.user.userId;
    try {
        // Fetch orders and basic details
        const { rows } = await db.query(
            "SELECT id, total_amount, status, payment_method, created_at FROM orders WHERE user_id = $1 ORDER BY created_at DESC", 
            [userId]
        );
        // TODO: Optionally fetch order items for each order (could be a separate endpoint or join)
        res.status(200).json(rows);
    } catch (error) {
        console.error(`Error fetching orders for user ${userId}:`, error);
        res.status(500).json({ message: "Error fetching orders" });
    }
};

// Get all orders (Admin only)
exports.getAllOrders = async (req, res) => {
    // TODO: Add pagination
    try {
        const { rows } = await db.query(
            `SELECT o.id, o.total_amount, o.status, o.payment_method, o.shipping_address, o.created_at, u.email as user_email 
             FROM orders o 
             LEFT JOIN users u ON o.user_id = u.id 
             ORDER BY o.created_at DESC`
        );
        // TODO: Fetch order items details if needed
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching all orders:", error);
        res.status(500).json({ message: "Error fetching all orders" });
    }
};

// Update order status (Admin only)
exports.updateOrderStatus = async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    // TODO: Validate status value (e.g., must be one of 'pending', 'processing', 'shipped', 'delivered', 'cancelled')
    if (!status) {
        return res.status(400).json({ message: "Status is required" });
    }

    try {
        const { rows } = await db.query(
            "UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *",
            [status, id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }
        // TODO: Optionally send email notification on status change
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(`Error updating status for order ${id}:`, error);
        res.status(500).json({ message: "Error updating order status" });
    }
};

// Get single order details (including items) - Could be for user or admin
exports.getOrderDetails = async (req, res) => {
    const { id } = req.params;
    const userId = req.user?.userId; // Get user ID if authenticated

    try {
        // Fetch order details
        const orderRes = await db.query(
            `SELECT o.*, u.email as user_email 
             FROM orders o 
             LEFT JOIN users u ON o.user_id = u.id 
             WHERE o.id = $1`, 
            [id]
        );

        if (orderRes.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        const order = orderRes.rows[0];

        // Security check: If user is not admin, ensure they own the order
        // TODO: Implement isAdmin check properly
        // if (!req.user.isAdmin && order.user_id !== userId) {
        //     return res.status(403).json({ message: "Forbidden: You do not own this order" });
        // }

        // Fetch order items
        const itemsRes = await db.query(
            `SELECT oi.quantity, oi.price_at_purchase, p.id as product_id, p.name_ar, p.name_en, p.image_url 
             FROM order_items oi 
             JOIN products p ON oi.product_id = p.id 
             WHERE oi.order_id = $1`, 
            [id]
        );

        res.status(200).json({ ...order, items: itemsRes.rows });

    } catch (error) {
        console.error(`Error fetching details for order ${id}:`, error);
        res.status(500).json({ message: "Error fetching order details" });
    }
};

