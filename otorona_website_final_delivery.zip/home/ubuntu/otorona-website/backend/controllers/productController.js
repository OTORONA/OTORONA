// Placeholder for Product Controller Logic
const db = require("../db");

// Get all products (with basic filtering/pagination options)
exports.getAllProducts = async (req, res) => {
    // TODO: Implement filtering (category, price range), sorting, pagination
    try {
        const { rows } = await db.query("SELECT id, name_ar, name_en, price, image_url, size_ml, concentration FROM products ORDER BY created_at DESC");
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching products:", error);
        res.status(500).json({ message: "Error fetching products" });
    }
};

// Get a single product by ID
exports.getProductById = async (req, res) => {
    const { id } = req.params;
    try {
        const { rows } = await db.query("SELECT * FROM products WHERE id = $1", [id]);
        if (rows.length === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(`Error fetching product ${id}:`, error);
        res.status(500).json({ message: "Error fetching product" });
    }
};

// Create a new product (Admin only - needs middleware later)
exports.createProduct = async (req, res) => {
    // TODO: Add validation, authorization (admin check)
    const { name_ar, name_en, description_ar, description_en, price, image_url, stock_quantity, category_id, concentration, size_ml } = req.body;
    try {
        const { rows } = await db.query(
            "INSERT INTO products (name_ar, name_en, description_ar, description_en, price, image_url, stock_quantity, category_id, concentration, size_ml) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *",
            [name_ar, name_en, description_ar, description_en, price, image_url, stock_quantity, category_id, concentration, size_ml]
        );
        res.status(201).json(rows[0]);
    } catch (error) {
        console.error("Error creating product:", error);
        res.status(500).json({ message: "Error creating product" });
    }
};

// Update a product (Admin only - needs middleware later)
exports.updateProduct = async (req, res) => {
    // TODO: Add validation, authorization (admin check)
    const { id } = req.params;
    const { name_ar, name_en, description_ar, description_en, price, image_url, stock_quantity, category_id, concentration, size_ml } = req.body;
    try {
        const { rows } = await db.query(
            "UPDATE products SET name_ar = $1, name_en = $2, description_ar = $3, description_en = $4, price = $5, image_url = $6, stock_quantity = $7, category_id = $8, concentration = $9, size_ml = $10, updated_at = NOW() WHERE id = $11 RETURNING *",
            [name_ar, name_en, description_ar, description_en, price, image_url, stock_quantity, category_id, concentration, size_ml, id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(`Error updating product ${id}:`, error);
        res.status(500).json({ message: "Error updating product" });
    }
};

// Delete a product (Admin only - needs middleware later)
exports.deleteProduct = async (req, res) => {
    // TODO: Add authorization (admin check)
    const { id } = req.params;
    try {
        const result = await db.query("DELETE FROM products WHERE id = $1 RETURNING id", [id]);
        if (result.rowCount === 0) {
            return res.status(404).json({ message: "Product not found" });
        }
        res.status(204).send(); // No content
    } catch (error) {
        // Handle potential foreign key constraint error (e.g., product in an order)
        if (error.code === '23503') { // Foreign key violation
             return res.status(400).json({ message: "Cannot delete product as it exists in existing orders." });
        }
        console.error(`Error deleting product ${id}:`, error);
        res.status(500).json({ message: "Error deleting product" });
    }
};

