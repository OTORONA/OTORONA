// Placeholder for Special Order Controller Logic
const db = require("../db");

// Submit a new special order request
exports.submitSpecialOrder = async (req, res) => {
    const {
        user_name,
        user_email,
        user_phone,
        description,
        requested_concentration,
        requested_bottle,
        requested_size_ml,
        notes
    } = req.body;

    // Basic validation
    if (!user_name || !user_email || !description) {
        return res.status(400).json({ message: "Name, email, and description are required for special orders." });
    }
    // TODO: Add email format validation

    try {
        const { rows } = await db.query(
            `INSERT INTO special_orders 
             (user_name, user_email, user_phone, description, requested_concentration, requested_bottle, requested_size_ml, notes, status)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending') RETURNING id, created_at`,
            [user_name, user_email, user_phone, description, requested_concentration, requested_bottle, requested_size_ml, notes]
        );

        // TODO: Send notification email to admin and confirmation to user

        res.status(201).json({ 
            message: "Special order request submitted successfully. We will contact you soon.", 
            requestId: rows[0].id,
            createdAt: rows[0].created_at
        });

    } catch (error) {
        console.error("Error submitting special order:", error);
        res.status(500).json({ message: "Error submitting special order request" });
    }
};

// Get all special orders (Admin only)
exports.getAllSpecialOrders = async (req, res) => {
    // TODO: Add pagination, filtering by status
    try {
        const { rows } = await db.query(
            "SELECT * FROM special_orders ORDER BY created_at DESC"
        );
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching special orders:", error);
        res.status(500).json({ message: "Error fetching special orders" });
    }
};

// Update special order status (Admin only)
exports.updateSpecialOrderStatus = async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    // TODO: Validate status value
    if (!status) {
        return res.status(400).json({ message: "Status is required" });
    }

    try {
        const { rows } = await db.query(
            "UPDATE special_orders SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *",
            [status, id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Special order request not found" });
        }
        // TODO: Optionally send email notification to user on status change
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(`Error updating status for special order ${id}:`, error);
        res.status(500).json({ message: "Error updating special order status" });
    }
};

