// Placeholder for Auth Controller Logic
const db = require("../db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const SALT_ROUNDS = 10;

// User Registration
exports.register = async (req, res) => {
    const { name, email, password } = req.body;

    // Basic validation
    if (!name || !email || !password) {
        return res.status(400).json({ message: "Name, email, and password are required" });
    }
    // TODO: Add more robust validation (email format, password strength)

    try {
        // Check if user already exists
        const existingUser = await db.query("SELECT id FROM users WHERE email = $1", [email]);
        if (existingUser.rows.length > 0) {
            return res.status(409).json({ message: "Email already in use" }); // 409 Conflict
        }

        // Hash the password
        const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

        // Insert new user
        const { rows } = await db.query(
            "INSERT INTO users (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, name, email, created_at",
            [name, email, passwordHash]
        );

        // Don't send password hash back
        res.status(201).json(rows[0]);

    } catch (error) {
        console.error("Error registering user:", error);
        res.status(500).json({ message: "Error registering user" });
    }
};

// User Login
exports.login = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
    }

    try {
        // Find user by email
        const { rows } = await db.query("SELECT id, name, email, password_hash FROM users WHERE email = $1", [email]);
        if (rows.length === 0) {
            return res.status(401).json({ message: "Invalid credentials" }); // Unauthorized
        }

        const user = rows[0];

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            return res.status(401).json({ message: "Invalid credentials" }); // Unauthorized
        }

        // Generate JWT
        const payload = { userId: user.id, name: user.name, email: user.email }; // Include necessary info, NOT password hash
        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "1d" }); // Token expires in 1 day

        // Send token and user info (without password hash)
        res.status(200).json({
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email
            }
        });

    } catch (error) {
        console.error("Error logging in user:", error);
        res.status(500).json({ message: "Error logging in user" });
    }
};

// Get User Profile (Protected Route)
exports.getProfile = async (req, res) => {
    // User ID is attached to req by the authenticateToken middleware
    const userId = req.user.userId;

    try {
        const { rows } = await db.query("SELECT id, name, email, created_at FROM users WHERE id = $1", [userId]);
        if (rows.length === 0) {
            return res.status(404).json({ message: "User not found" });
        }
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(`Error fetching profile for user ${userId}:`, error);
        res.status(500).json({ message: "Error fetching profile" });
    }
};

// Update User Profile (Protected Route)
exports.updateProfile = async (req, res) => {
    const userId = req.user.userId;
    const { name, email } = req.body; // Allow updating name and email, password update could be separate

    // Basic validation
    if (!name && !email) {
        return res.status(400).json({ message: "Name or email must be provided for update" });
    }
    // TODO: Add email format validation if email is provided

    try {
        // Check if the new email is already taken by another user
        if (email) {
            const existingUser = await db.query("SELECT id FROM users WHERE email = $1 AND id != $2", [email, userId]);
            if (existingUser.rows.length > 0) {
                return res.status(409).json({ message: "Email already in use by another account" });
            }
        }

        // Build the update query dynamically
        let query = "UPDATE users SET ";
        const values = [];
        let valueIndex = 1;

        if (name) {
            query += `name = $${valueIndex++}, `;
            values.push(name);
        }
        if (email) {
            query += `email = $${valueIndex++}, `;
            values.push(email);
        }

        query += `updated_at = NOW() WHERE id = $${valueIndex++} RETURNING id, name, email, updated_at`;
        values.push(userId);

        const { rows } = await db.query(query, values);

        if (rows.length === 0) {
            // This shouldn't happen if the user exists (checked by middleware)
            return res.status(404).json({ message: "User not found" });
        }

        res.status(200).json(rows[0]);

    } catch (error) {
        console.error(`Error updating profile for user ${userId}:`, error);
        res.status(500).json({ message: "Error updating profile" });
    }
};

