// Placeholder for Category Controller Logic
const db = require("../db");

// Get all categories
exports.getAllCategories = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT id, name_ar, name_en FROM categories ORDER BY name_ar ASC");
        res.status(200).json(rows);
    } catch (error) {
        console.error("Error fetching categories:", error);
        res.status(500).json({ message: "Error fetching categories" });
    }
};

// Get a single category by ID
exports.getCategoryById = async (req, res) => {
    const { id } = req.params;
    try {
        const { rows } = await db.query("SELECT id, name_ar, name_en FROM categories WHERE id = $1", [id]);
        if (rows.length === 0) {
            return res.status(404).json({ message: "Category not found" });
        }
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(`Error fetching category ${id}:`, error);
        res.status(500).json({ message: "Error fetching category" });
    }
};

// Create a new category (Admin only - needs middleware later)
exports.createCategory = async (req, res) => {
    // TODO: Add validation, authorization (admin check)
    const { name_ar, name_en } = req.body;
    if (!name_ar || !name_en) {
        return res.status(400).json({ message: "Arabic and English names are required" });
    }
    try {
        const { rows } = await db.query(
            "INSERT INTO categories (name_ar, name_en) VALUES ($1, $2) RETURNING *",
            [name_ar, name_en]
        );
        res.status(201).json(rows[0]);
    } catch (error) {
        console.error("Error creating category:", error);
        // Handle potential unique constraint violation if needed
        res.status(500).json({ message: "Error creating category" });
    }
};

// Update a category (Admin only - needs middleware later)
exports.updateCategory = async (req, res) => {
    // TODO: Add validation, authorization (admin check)
    const { id } = req.params;
    const { name_ar, name_en } = req.body;
    if (!name_ar || !name_en) {
        return res.status(400).json({ message: "Arabic and English names are required" });
    }
    try {
        const { rows } = await db.query(
            "UPDATE categories SET name_ar = $1, name_en = $2, updated_at = NOW() WHERE id = $3 RETURNING *",
            [name_ar, name_en, id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: "Category not found" });
        }
        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(`Error updating category ${id}:`, error);
        res.status(500).json({ message: "Error updating category" });
    }
};

// Delete a category (Admin only - needs middleware later)
exports.deleteCategory = async (req, res) => {
    // TODO: Add authorization (admin check)
    // Consider implications: What happens to products in this category? Schema sets category_id to NULL.
    const { id } = req.params;
    try {
        const result = await db.query("DELETE FROM categories WHERE id = $1 RETURNING id", [id]);
        if (result.rowCount === 0) {
            return res.status(404).json({ message: "Category not found" });
        }
        res.status(204).send(); // No content
    } catch (error) {
        console.error(`Error deleting category ${id}:`, error);
        res.status(500).json({ message: "Error deleting category" });
    }
};

