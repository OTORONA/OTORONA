require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

// Import database connection
const db = require("./db"); // Ensure DB connection is tested on startup

// Import routes
const productRoutes = require("./routes/products");
const authRoutes = require("./routes/auth");
const orderRoutes = require("./routes/orders");
const categoryRoutes = require("./routes/categories");
const specialOrderRoutes = require("./routes/specialOrders");

const app = express();

// Basic Middleware
app.use(cors()); // Enable CORS for all origins (adjust for production)
app.use(helmet()); // Apply basic security headers
app.use(express.json()); // Parse JSON request bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded request bodies

// Basic Health Check Route
app.get("/api/health", (req, res) => {
  res.status(200).json({ status: "UP", timestamp: new Date().toISOString() });
});

// Mount Routers
app.use("/api/products", productRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/special-orders", specialOrderRoutes);

// Simple Error Handling Middleware (can be expanded)
app.use((err, req, res, next) => {
  console.error("Unhandled Error:", err.stack);
  // Avoid sending stack trace in production
  res.status(500).json({ message: "Something went wrong on the server." });
});

// Handle 404 Not Found
app.use((req, res, next) => {
  res.status(404).json({ message: "Resource not found" });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, "0.0.0.0", () => { // Listen on 0.0.0.0 to be accessible externally
  console.log(`Server running on port ${PORT}`);
});

// Export app for potential testing
module.exports = app;

