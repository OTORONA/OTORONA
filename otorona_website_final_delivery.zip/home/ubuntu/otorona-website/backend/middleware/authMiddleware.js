const jwt = require("jsonwebtoken");
require("dotenv").config();

// Middleware to verify JWT token
exports.authenticateToken = (req, res, next) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1]; // Bearer TOKEN

    if (token == null) {
        return res.sendStatus(401); // if there isn't any token
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            console.error("JWT Verification Error:", err.message);
            return res.sendStatus(403); // Invalid token
        }
        req.user = user; // Add user payload to request object
        next(); // Proceed to the next middleware or route handler
    });
};

// Middleware to check if user is admin (Placeholder - needs admin role in DB/JWT)
exports.isAdmin = (req, res, next) => {
    // TODO: Implement actual admin check based on user role from DB or JWT payload
    // For now, assuming any authenticated user might be admin for testing
    // In production, this MUST check for a specific role or permission.
    // Example: if (req.user.role !== 'admin') return res.sendStatus(403);
    console.warn("isAdmin middleware is a placeholder. Implement proper role check!");
    next();
};

