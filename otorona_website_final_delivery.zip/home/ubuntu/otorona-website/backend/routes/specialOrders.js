const express = require("express");
const specialOrderController = require("../controllers/specialOrderController");
const { authenticateToken, isAdmin } = require("../middleware/authMiddleware");

const router = express.Router();

// Submit a special order request (Public)
router.post("/submit", specialOrderController.submitSpecialOrder);

// --- Admin Routes ---
// Add isAdmin middleware once implemented properly

// Get all special order requests (Admin only)
router.get("/admin/all", authenticateToken, /* isAdmin, */ specialOrderController.getAllSpecialOrders); // Add isAdmin later

// Update special order status (Admin only)
router.put("/admin/status/:id", authenticateToken, /* isAdmin, */ specialOrderController.updateSpecialOrderStatus); // Add isAdmin later

module.exports = router;

