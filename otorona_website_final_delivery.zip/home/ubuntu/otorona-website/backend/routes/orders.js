const express = require("express");
const orderController = require("../controllers/orderController");
const { authenticateToken, isAdmin } = require("../middleware/authMiddleware");

const router = express.Router();

// Create a new order (Authenticated users or potentially guests - controller handles user_id)
// Applying authenticateToken here makes it mandatory for users to be logged in to order.
// If guest checkout is desired, remove authenticateToken and handle user_id=null in controller.
router.post("/", authenticateToken, orderController.createOrder);

// Get orders for the logged-in user
router.get("/my-orders", authenticateToken, orderController.getUserOrders);

// Get details of a specific order (User must own it or be admin)
// The controller should contain the logic to check ownership if user is not admin
router.get("/:id", authenticateToken, orderController.getOrderDetails);

// --- Admin Routes ---
// Add isAdmin middleware once implemented properly

// Get all orders (Admin only)
router.get("/admin/all", authenticateToken, /* isAdmin, */ orderController.getAllOrders); // Add isAdmin later

// Update order status (Admin only)
router.put("/admin/status/:id", authenticateToken, /* isAdmin, */ orderController.updateOrderStatus); // Add isAdmin later


module.exports = router;

