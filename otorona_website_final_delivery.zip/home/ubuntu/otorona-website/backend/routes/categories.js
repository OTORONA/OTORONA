const express = require("express");
const categoryController = require("../controllers/categoryController");
// const { isAdmin, authenticateToken } = require('../middleware/authMiddleware'); // TODO: Add auth middleware later

const router = express.Router();

// Public routes
router.get("/", categoryController.getAllCategories);
router.get("/:id", categoryController.getCategoryById);

// Admin routes (add middleware later)
// router.post("/", authenticateToken, isAdmin, categoryController.createCategory);
// router.put("/:id", authenticateToken, isAdmin, categoryController.updateCategory);
// router.delete("/:id", authenticateToken, isAdmin, categoryController.deleteCategory);

// Placeholder for admin routes without auth for now
router.post("/", categoryController.createCategory); // WARNING: No auth yet
router.put("/:id", categoryController.updateCategory); // WARNING: No auth yet
router.delete("/:id", categoryController.deleteCategory); // WARNING: No auth yet

module.exports = router;

