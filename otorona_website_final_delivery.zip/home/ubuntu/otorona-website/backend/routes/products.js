const express = require("express");
const productController = require("../controllers/productController");
// const { isAdmin, authenticateToken } = require('../middleware/authMiddleware'); // TODO: Add auth middleware later

const router = express.Router();

// Public routes
router.get("/", productController.getAllProducts);
router.get("/:id", productController.getProductById);

// Admin routes (add middleware later)
// router.post("/", authenticateToken, isAdmin, productController.createProduct);
// router.put("/:id", authenticateToken, isAdmin, productController.updateProduct);
// router.delete("/:id", authenticateToken, isAdmin, productController.deleteProduct);

// Placeholder for admin routes without auth for now
router.post("/", productController.createProduct); // WARNING: No auth yet
router.put("/:id", productController.updateProduct); // WARNING: No auth yet
router.delete("/:id", productController.deleteProduct); // WARNING: No auth yet

module.exports = router;

