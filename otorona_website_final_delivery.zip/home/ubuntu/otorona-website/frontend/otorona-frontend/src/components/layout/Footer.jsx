import React from 'react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  // TODO: Add links (About Us, Contact, Terms, Privacy)
  return (
    <footer className="bg-gray-100 text-gray-600 py-8 mt-16">
      <div className="container mx-auto px-4 text-center">
        <p>&copy; {currentYear} عطورنا. جميع الحقوق محفوظة.</p>
        <div className="mt-4">
          {/* Placeholder for footer links */}
          <span className="mx-2 hover:text-gray-800 cursor-pointer">من نحن</span>
          <span className="mx-2 hover:text-gray-800 cursor-pointer">اتصل بنا</span>
          <span className="mx-2 hover:text-gray-800 cursor-pointer">الشروط والأحكام</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

