import React from 'react';

const Header = () => {
  // TODO: Add navigation, language switcher, user profile/login link, cart icon
  return (
    <header className="bg-white shadow-md py-4">
      <nav className="container mx-auto px-4 flex justify-between items-center">
        <div className="text-2xl font-bold text-gray-800">عطورنا</div>
        <div>
          {/* Placeholder for nav links */}
          <span className="mx-2 text-gray-600 hover:text-gray-800 cursor-pointer">الرئيسية</span>
          <span className="mx-2 text-gray-600 hover:text-gray-800 cursor-pointer">المتجر</span>
          <span className="mx-2 text-gray-600 hover:text-gray-800 cursor-pointer">طلبات خاصة</span>
          {/* TODO: Add Language switcher, Cart, User icon */}
        </div>
      </nav>
    </header>
  );
};

export default Header;

