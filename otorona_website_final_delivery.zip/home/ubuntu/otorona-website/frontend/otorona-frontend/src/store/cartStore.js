import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Helper function to calculate total price
const calculateTotal = (items) => {
  return items.reduce((total, item) => total + item.price * item.quantity, 0);
};

const useCartStore = create(
  persist(
    (set, get) => ({
      items: [], // Array of { product_id, name_ar, name_en, price, image_url, quantity }
      totalItems: 0,
      totalPrice: 0,

      // Add item to cart or increase quantity
      addItem: (product, quantity = 1) => {
        const existingItemIndex = get().items.findIndex(item => item.product_id === product.id);
        let newItems;
        if (existingItemIndex > -1) {
          // Increase quantity
          newItems = [...get().items];
          newItems[existingItemIndex].quantity += quantity;
        } else {
          // Add new item
          newItems = [...get().items, { 
            product_id: product.id, 
            name_ar: product.name_ar, 
            name_en: product.name_en, 
            price: product.price, 
            image_url: product.image_url, 
            quantity 
          }];
        }
        const newTotalItems = get().totalItems + quantity;
        const newTotalPrice = calculateTotal(newItems);
        set({ items: newItems, totalItems: newTotalItems, totalPrice: newTotalPrice });
        console.log("Cart updated:", get().items);
      },

      // Remove item from cart
      removeItem: (productId) => {
        const itemToRemove = get().items.find(item => item.product_id === productId);
        if (!itemToRemove) return;

        const newItems = get().items.filter(item => item.product_id !== productId);
        const newTotalItems = get().totalItems - itemToRemove.quantity;
        const newTotalPrice = calculateTotal(newItems);
        set({ items: newItems, totalItems: newTotalItems, totalPrice: newTotalPrice });
      },

      // Update item quantity
      updateItemQuantity: (productId, newQuantity) => {
        if (newQuantity < 1) {
          get().removeItem(productId); // Remove if quantity is less than 1
          return;
        }
        const newItems = get().items.map(item => 
          item.product_id === productId ? { ...item, quantity: newQuantity } : item
        );
        const newTotalItems = newItems.reduce((sum, item) => sum + item.quantity, 0);
        const newTotalPrice = calculateTotal(newItems);
        set({ items: newItems, totalItems: newTotalItems, totalPrice: newTotalPrice });
      },

      // Clear cart
      clearCart: () => {
        set({ items: [], totalItems: 0, totalPrice: 0 });
      },
    }),
    {
      name: 'otorona-cart-storage', // unique name for localStorage key
      // getStorage: () => localStorage, // (optional) by default, uses localStorage
    }
  )
);

export default useCartStore;

