import React, { useState } from 'react';
import axios from 'axios'; // Assuming axios is installed
// TODO: Add form validation and better feedback (e.g., loading spinner, success/error messages)

const SpecialOrderPage = () => {
  const [formData, setFormData] = useState({
    user_name: '',
    user_email: '',
    user_phone: '',
    description: '', // Description of the desired perfume
    requested_concentration: '', // e.g., 40%
    requested_bottle: '', // e.g., Standard 30ml, Premium 50ml
    requested_size_ml: '', // e.g., 30, 50
    notes: '' // Any additional notes
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    // Basic validation
    if (!formData.user_name || !formData.user_email || !formData.description) {
      setError("يرجى ملء حقول الاسم والبريد الإلكتروني ووصف العطر المطلوب (*).");
      return;
    }

    setLoading(true);

    try {
      // TODO: Replace with actual API endpoint
      const response = await axios.post('http://localhost:5000/api/special-orders/submit', formData);
      
      setSuccess(response.data.message || "تم إرسال طلبك الخاص بنجاح. سنتواصل معك قريباً.");
      // Clear form after successful submission
      setFormData({
        user_name: '', user_email: '', user_phone: '', description: '',
        requested_concentration: '', requested_bottle: '', requested_size_ml: '', notes: ''
      });

    } catch (err) {
      console.error("Error submitting special order:", err);
      setError(err.response?.data?.message || "حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-8 text-center">طلب عطر خاص</h1>
      <p className="text-center text-gray-600 mb-8">هل لديك فكرة لعطر مميز؟ صف لنا ما تبحث عنه وسنبذل قصارى جهدنا لتحقيقه لك بالتركيز والحجم الذي تفضله.</p>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow border">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="user_name" className="block text-sm font-medium text-gray-700 mb-1">الاسم الكامل *</label>
            <input type="text" id="user_name" name="user_name" value={formData.user_name} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
          </div>
          <div>
            <label htmlFor="user_email" className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني *</label>
            <input type="email" id="user_email" name="user_email" value={formData.user_email} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
          </div>
        </div>
        <div className="mb-4">
          <label htmlFor="user_phone" className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف (اختياري)</label>
          <input type="tel" id="user_phone" name="user_phone" value={formData.user_phone} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
        </div>
        <div className="mb-4">
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">وصف العطر المطلوب *</label>
          <textarea id="description" name="description" value={formData.description} onChange={handleInputChange} required rows="4" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" placeholder="مثال: أريد عطراً يشبه عطر X ولكن بلمسة من العود، أو عطر زهري منعش للصيف..."></textarea>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label htmlFor="requested_concentration" className="block text-sm font-medium text-gray-700 mb-1">التركيز المطلوب (%)</label>
            <input type="number" id="requested_concentration" name="requested_concentration" value={formData.requested_concentration} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" placeholder="مثال: 40" />
          </div>
          <div>
            <label htmlFor="requested_size_ml" className="block text-sm font-medium text-gray-700 mb-1">الحجم المطلوب (مل)</label>
            <input type="number" id="requested_size_ml" name="requested_size_ml" value={formData.requested_size_ml} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" placeholder="مثال: 30 أو 50" />
          </div>
          <div>
            <label htmlFor="requested_bottle" className="block text-sm font-medium text-gray-700 mb-1">نوع القنينة</label>
            <input type="text" id="requested_bottle" name="requested_bottle" value={formData.requested_bottle} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" placeholder="مثال: قياسية، فاخرة..." />
          </div>
        </div>
        <div className="mb-6">
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">ملاحظات إضافية</label>
          <textarea id="notes" name="notes" value={formData.notes} onChange={handleInputChange} rows="3" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"></textarea>
        </div>

        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
        {success && <p className="text-green-600 text-sm mb-4">{success}</p>}

        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-purple-600 text-white font-semibold py-3 px-6 rounded hover:bg-purple-700 transition duration-300 disabled:opacity-50"
        >
          {loading ? 'جاري الإرسال...' : 'إرسال طلب خاص'}
        </button>
      </form>
    </div>
  );
};

export default SpecialOrderPage;

