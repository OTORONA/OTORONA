import React, { useState, useEffect } from 'react';
import axios from 'axios'; // Assuming axios is installed
// TODO: Import auth store to get user info and token
// TODO: Add form validation and feedback messages

const ProfilePage = () => {
  // Placeholder for user data - fetch from API or auth store
  const [user, setUser] = useState({ name: 'اسم المستخدم', email: 'user@example.com' }); 
  const [orders, setOrders] = useState([]);
  const [loadingProfile, setLoadingProfile] = useState(false); // Separate loading states
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [errorProfile, setErrorProfile] = useState(null);
  const [errorOrders, setErrorOrders] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '' });

  // TODO: Replace with actual token retrieval
  const authToken = 'YOUR_AUTH_TOKEN'; // Placeholder

  useEffect(() => {
    // Fetch user profile
    const fetchProfile = async () => {
      setLoadingProfile(true);
      setErrorProfile(null);
      try {
        // TODO: Replace with actual API endpoint and use auth token
        const response = await axios.get('http://localhost:5000/api/auth/profile', {
          headers: { Authorization: `Bearer ${authToken}` }
        });
        setUser(response.data);
        setFormData({ name: response.data.name, email: response.data.email });
      } catch (err) {
        console.error("Error fetching profile:", err);
        setErrorProfile('فشل تحميل معلومات الملف الشخصي.');
      }
      setLoadingProfile(false);
    };

    // Fetch user orders
    const fetchOrders = async () => {
      setLoadingOrders(true);
      setErrorOrders(null);
      try {
        // TODO: Replace with actual API endpoint and use auth token
        const response = await axios.get('http://localhost:5000/api/orders/my-orders', {
          headers: { Authorization: `Bearer ${authToken}` }
        });
        setOrders(response.data);
      } catch (err) {
        console.error("Error fetching orders:", err);
        setErrorOrders('فشل تحميل قائمة الطلبات.');
      }
      setLoadingOrders(false);
    };

    fetchProfile();
    fetchOrders();
  }, [authToken]); // Refetch if token changes

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setErrorProfile(null);
    setLoadingProfile(true);
    try {
      // TODO: Replace with actual API endpoint and use auth token
      const response = await axios.put('http://localhost:5000/api/auth/profile', formData, {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      setUser(response.data);
      setEditMode(false);
      // TODO: Show success message
    } catch (err) {
      console.error("Error updating profile:", err);
      setErrorProfile(err.response?.data?.message || 'فشل تحديث الملف الشخصي.');
    } finally {
      setLoadingProfile(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">حسابي</h1>

      {/* Profile Section */}
      <section className="mb-12 bg-white p-6 rounded-lg shadow border">
        <h2 className="text-xl font-semibold mb-4">معلومات الملف الشخصي</h2>
        {loadingProfile && <p>جاري تحميل الملف الشخصي...</p>}
        {errorProfile && <p className="text-red-500 mb-4">{errorProfile}</p>}
        {!loadingProfile && !errorProfile && (
          editMode ? (
            <form onSubmit={handleUpdateProfile}>
              <div className="mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
                <input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
              </div>
              <div className="flex gap-4">
                 <button type="submit" disabled={loadingProfile} className="bg-purple-600 text-white font-semibold py-2 px-4 rounded hover:bg-purple-700 transition duration-300 disabled:opacity-50">
                  {loadingProfile ? 'جاري الحفظ...' : 'حفظ التغييرات'}
                </button>
                <button type="button" onClick={() => setEditMode(false)} className="text-gray-600 py-2 px-4 rounded hover:bg-gray-100 transition duration-300">
                  إلغاء
                </button>
              </div>
            </form>
          ) : (
            <div>
              <p className="mb-2"><span className="font-semibold">الاسم:</span> {user.name}</p>
              <p className="mb-4"><span className="font-semibold">البريد الإلكتروني:</span> {user.email}</p>
              <button onClick={() => setEditMode(true)} className="text-purple-600 hover:text-purple-800 font-semibold">
                تعديل الملف الشخصي
              </button>
              {/* TODO: Add Change Password option */}
            </div>
          )
        )}
      </section>

      {/* Orders Section */}
      <section>
        <h2 className="text-xl font-semibold mb-4">طلباتي السابقة</h2>
        {loadingOrders && <p>جاري تحميل الطلبات...</p>}
        {errorOrders && <p className="text-red-500">{errorOrders}</p>}
        {!loadingOrders && !errorOrders && (
          orders.length === 0 ? (
            <p className="text-gray-500">لم تقم بأي طلبات بعد.</p>
          ) : (
            <div className="border rounded-lg overflow-hidden shadow">
              {orders.map(order => (
                <div key={order.id} className="flex justify-between items-center p-4 border-b last:border-b-0 bg-white">
                  <div>
                    <p className="font-semibold">طلب رقم: {order.id}</p>
                    <p className="text-sm text-gray-500">التاريخ: {new Date(order.created_at).toLocaleDateString('ar-EG')}</p>
                  </div>
                  <div>
                    <p className="font-semibold">{order.total_amount.toFixed(2)} د.م.</p>
                    <p className={`text-sm font-medium ${order.status === 'delivered' ? 'text-green-600' : order.status === 'cancelled' ? 'text-red-600' : 'text-yellow-600'}`}>
                      {/* TODO: Translate status */}
                      {order.status}
                    </p>
                  </div>
                  {/* TODO: Add Link to order details page */}
                  <button className="text-purple-600 hover:text-purple-800 text-sm">عرض التفاصيل</button>
                </div>
              ))}
            </div>
          )
        )}
      </section>
    </div>
  );
};

export default ProfilePage;

