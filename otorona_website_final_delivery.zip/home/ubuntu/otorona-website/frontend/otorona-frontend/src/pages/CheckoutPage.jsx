import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import useCartStore from '../store/cartStore';
import axios from 'axios'; // Assuming axios is installed
// TODO: Get user info if logged in to prefill form

const CheckoutPage = () => {
  const { items, totalPrice, totalItems, clearCart } = useCartStore();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    phone: '',
    email: '', // Optional, but good for confirmation
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmitOrder = async (e) => {
    e.preventDefault();
    setError(null);

    if (items.length === 0) {
      setError("سلة التسوق فارغة. لا يمكنك إتمام الطلب.");
      return;
    }

    // Basic validation
    if (!formData.name || !formData.address || !formData.city || !formData.phone) {
      setError("يرجى ملء جميع حقول العنوان المطلوبة (*).");
      return;
    }

    setLoading(true);

    const orderData = {
      items: items.map(item => ({ product_id: item.product_id, quantity: item.quantity })),
      shipping_address: {
        name: formData.name,
        address: formData.address,
        city: formData.city,
        phone: formData.phone,
        email: formData.email, // Include email if provided
      },
      // billing_address can be same as shipping for COD
      billing_address: {
        name: formData.name,
        address: formData.address,
        city: formData.city,
        phone: formData.phone,
        email: formData.email,
      },
      // Payment method is implicitly COD based on backend logic
    };

    try {
      // TODO: Replace with actual API endpoint and add auth token if user is logged in
      const response = await axios.post('http://localhost:5000/api/orders', orderData, {
        // headers: { Authorization: `Bearer ${authToken}` } // Add if user is logged in
      });
      
      // Order successful
      clearCart();
      // Navigate to order confirmation page with order details
      navigate('/order-confirmation', { state: { order: response.data } }); 

    } catch (err) {
      console.error("Error placing order:", err);
      setError(err.response?.data?.message || "حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  if (items.length === 0 && !error) {
    // Redirect to cart or shop if cart is empty (or show message)
    // This check is also done in handleSubmit, but good for initial render
    return (
        <div className="text-center py-12">
          <p className="text-xl text-gray-500 mb-4">سلة التسوق فارغة. لا يمكنك إتمام الدفع.</p>
          {/* Optional: Add link back to shop */}
        </div>
      );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">إتمام الطلب</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Shipping Information Form */}
        <div className="md:col-span-2 bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-6">معلومات الشحن (الدفع عند الاستلام)</h2>
          <form onSubmit={handleSubmitOrder}>
            <div className="mb-4">
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">الاسم الكامل *</label>
              <input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
            </div>
            <div className="mb-4">
              <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">العنوان بالتفصيل *</label>
              <input type="text" id="address" name="address" value={formData.address} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" placeholder="الحي، الشارع، رقم المنزل..." />
            </div>
            <div className="mb-4">
              <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">المدينة *</label>
              <input type="text" id="city" name="city" value={formData.city} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
            </div>
            <div className="mb-4">
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">رقم الهاتف *</label>
              <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
            </div>
            <div className="mb-6">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني (اختياري)</label>
              <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" placeholder="لتلقي تأكيد الطلب" />
            </div>

            {error && <p className="text-red-500 text-sm mb-4">{error}</p>}

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-purple-600 text-white font-semibold py-3 px-6 rounded hover:bg-purple-700 transition duration-300 disabled:opacity-50"
            >
              {loading ? 'جاري إرسال الطلب...' : 'تأكيد الطلب (الدفع عند الاستلام)'}
            </button>
          </form>
        </div>

        {/* Order Summary */}
        <div className="md:col-span-1 bg-gray-50 p-6 rounded-lg shadow h-fit sticky top-8">
          <h2 className="text-xl font-semibold mb-6">ملخص الطلب</h2>
          {items.map(item => (
            <div key={item.product_id} className="flex justify-between items-center mb-3 pb-3 border-b last:border-b-0 text-sm">
              <div className='flex items-center'>
                <img src={item.image_url || '/placeholder.jpg'} alt={item.name_ar} className='w-10 h-10 object-contain rounded mr-2'/>
                <span>{item.name_ar} x {item.quantity}</span>
              </div>
              <span>{(item.price * item.quantity).toFixed(2)} د.م.</span>
            </div>
          ))}
          <div className="flex justify-between font-bold text-lg mt-4 pt-4 border-t">
            <span>المجموع الإجمالي:</span>
            <span>{totalPrice.toFixed(2)} د.م.</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;

