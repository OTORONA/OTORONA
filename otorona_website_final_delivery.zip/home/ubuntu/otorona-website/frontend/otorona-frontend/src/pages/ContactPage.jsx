import React, { useState } from 'react';
import axios from 'axios'; // Or use a form submission service

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    // Basic validation
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      setError("يرجى ملء جميع الحقول المطلوبة (*).");
      setLoading(false);
      return;
    }

    try {
      // TODO: Replace with actual backend endpoint for contact form submission
      // or integrate with a service like Formspree/Netlify Forms
      // Example using a placeholder endpoint:
      // await axios.post('http://localhost:5000/api/contact', formData);
      
      // Simulate successful submission for now
      await new Promise(resolve => setTimeout(resolve, 1000)); 
      console.log("Contact form submitted:", formData);

      setSuccess("تم إرسال رسالتك بنجاح. سنتواصل معك قريباً.");
      setFormData({ name: '', email: '', subject: '', message: '' }); // Clear form

    } catch (err) {
      console.error("Error submitting contact form:", err);
      setError("حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6 text-center">اتصل بنا</h1>
      <p className="text-center text-gray-600 mb-8">هل لديك سؤال أو استفسار؟ يسعدنا تواصلك معنا. يرجى ملء النموذج أدناه أو التواصل عبر المعلومات المتاحة.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Contact Form */}
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow border">
          <h2 className="text-xl font-semibold mb-4">أرسل لنا رسالة</h2>
          <div className="mb-4">
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">الاسم *</label>
            <input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني *</label>
            <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
          </div>
          <div className="mb-4">
            <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">الموضوع *</label>
            <input type="text" id="subject" name="subject" value={formData.subject} onChange={handleInputChange} required className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500" />
          </div>
          <div className="mb-6">
            <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">الرسالة *</label>
            <textarea id="message" name="message" value={formData.message} onChange={handleInputChange} required rows="5" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"></textarea>
          </div>

          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          {success && <p className="text-green-600 text-sm mb-4">{success}</p>}

          <button 
            type="submit" 
            disabled={loading}
            className="w-full bg-purple-600 text-white font-semibold py-3 px-6 rounded hover:bg-purple-700 transition duration-300 disabled:opacity-50"
          >
            {loading ? 'جاري الإرسال...' : 'إرسال الرسالة'}
          </button>
        </form>

        {/* Contact Info */}
        <div className="bg-gray-50 p-6 rounded-lg shadow border">
          <h2 className="text-xl font-semibold mb-4">معلومات التواصل</h2>
          <div className="space-y-4 text-gray-700">
            {/* TODO: Replace with actual contact details */}
            <p>
              <strong className="block text-gray-800">العنوان:</strong>
              شارع المثال، رقم 123، المدينة، المغرب
            </p>
            <p>
              <strong className="block text-gray-800">الهاتف:</strong>
              <a href="tel:+212XXXXXXXXX" className="hover:text-purple-700">+212 XXX XXX XXX</a>
            </p>
            <p>
              <strong className="block text-gray-800">البريد الإلكتروني:</strong>
              <a href="mailto:contact@otorona.ma" className="hover:text-purple-700">contact@otorona.ma</a>
            </p>
            <p>
              <strong className="block text-gray-800">ساعات العمل:</strong>
              الاثنين - الجمعة: 9:00 صباحاً - 6:00 مساءً
            </p>
            {/* TODO: Add social media links if available */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;

