import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

// TODO: Add loading and error states
// TODO: Add quantity selector
// TODO: Implement Add to Cart functionality

const ProductDetailPage = () => {
  const { id } = useParams(); // Get product ID from URL
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Replace with actual API endpoint from .env or config
        const response = await axios.get(`http://localhost:5000/api/products/${id}`);
        setProduct(response.data);
      } catch (err) {
        console.error(`Error fetching product ${id}:`, err);
        if (err.response && err.response.status === 404) {
          setError('Product not found.');
        } else {
          setError('Failed to load product details. Please try again later.');
        }
      }
      setLoading(false);
    };

    fetchProduct();
  }, [id]);

  const handleQuantityChange = (change) => {
    setQuantity(prev => Math.max(1, prev + change)); // Ensure quantity is at least 1
  };

  // TODO: Implement addToCart function
  const handleAddToCart = () => {
    console.log(`Adding ${quantity} of product ${id} to cart.`);
    // Call cart store action here
  };

  if (loading) return <p className="text-center text-gray-500">جاري تحميل تفاصيل المنتج...</p>;
  if (error) return <p className="text-center text-red-500">{error}</p>;
  if (!product) return <p className="text-center text-gray-500">لم يتم العثور على المنتج.</p>; // Should be caught by error state, but good fallback

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Image */}
        <div>
          <img 
            src={product.image_url || '/placeholder.jpg'} 
            alt={product.name_ar} 
            className="w-full h-auto max-h-[500px] object-contain rounded-lg shadow-md mb-4 md:mb-0"
          />
          {/* TODO: Add image gallery for multiple images if available */}
        </div>

        {/* Product Details */}
        <div>
          <h1 className="text-3xl font-bold mb-3">{product.name_ar}</h1>
          {product.name_en && <h2 className="text-xl text-gray-500 mb-4">{product.name_en}</h2>}
          
          <p className="text-2xl font-bold text-purple-700 mb-4">{product.price} د.م.</p>
          
          <div className="mb-4">
            <span className="font-semibold">التركيز:</span> {product.concentration}% زيت عطري
          </div>
          <div className="mb-6">
            <span className="font-semibold">الحجم:</span> {product.size_ml} مل
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="font-semibold text-lg mb-2">الوصف:</h3>
            <p className="text-gray-700 whitespace-pre-line">{product.description_ar || 'لا يوجد وصف متوفر.'}</p>
            {product.description_en && <p className="text-gray-500 mt-2 whitespace-pre-line">{product.description_en}</p>}
          </div>

          {/* Quantity Selector */}
          <div className="flex items-center mb-6">
            <span className="font-semibold mr-4">الكمية:</span>
            <button 
              onClick={() => handleQuantityChange(-1)} 
              className="bg-gray-200 px-3 py-1 rounded-l hover:bg-gray-300 disabled:opacity-50"
              disabled={quantity <= 1}
            >
              -
            </button>
            <span className="px-4 py-1 border-t border-b border-gray-200">{quantity}</span>
            <button 
              onClick={() => handleQuantityChange(1)} 
              className="bg-gray-200 px-3 py-1 rounded-r hover:bg-gray-300"
              // TODO: Optionally disable if quantity exceeds stock (need stock info from API)
            >
              +
            </button>
          </div>

          {/* Add to Cart Button */}
          <button 
            onClick={handleAddToCart}
            className="w-full bg-purple-600 text-white font-semibold py-3 px-6 rounded hover:bg-purple-700 transition duration-300 disabled:opacity-50"
            // TODO: Disable if product is out of stock (need stock info)
          >
            أضف إلى السلة
          </button>

          {/* TODO: Add stock status indicator */} 
          {/* <p className="mt-4 text-sm text-green-600">متوفر في المخزون</p> */}
          {/* <p className="mt-4 text-sm text-red-600">غير متوفر حالياً</p> */}

        </div>
      </div>

      {/* TODO: Add Related Products section */}
    </div>
  );
};

export default ProductDetailPage;

