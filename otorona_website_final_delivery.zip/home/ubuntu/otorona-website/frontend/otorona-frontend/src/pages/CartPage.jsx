import React from 'react';
import useCartStore from '../store/cartStore';
import { Link } from 'react-router-dom';

const CartPage = () => {
  const { items, totalItems, totalPrice, removeItem, updateItemQuantity, clearCart } = useCartStore();

  const handleQuantityChange = (productId, change) => {
    const item = items.find(i => i.product_id === productId);
    if (item) {
      updateItemQuantity(productId, item.quantity + change);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">سلة التسوق</h1>

      {items.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-xl text-gray-500 mb-4">سلة التسوق فارغة.</p>
          <Link to="/shop" className="bg-purple-600 text-white font-semibold py-2 px-6 rounded hover:bg-purple-700 transition duration-300">
            اذهب للتسوق
          </Link>
        </div>
      ) : (
        <div>
          {/* Cart Items Table/List */}
          <div className="mb-8 border rounded-lg overflow-hidden shadow">
            {items.map(item => (
              <div key={item.product_id} className="flex items-center justify-between p-4 border-b last:border-b-0 bg-white">
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  <img 
                    src={item.image_url || '/placeholder.jpg'} 
                    alt={item.name_ar} 
                    className="w-16 h-16 object-contain rounded"
                  />
                  <div>
                    <Link to={`/product/${item.product_id}`} className="font-semibold hover:text-purple-700">{item.name_ar}</Link>
                    <p className="text-sm text-gray-500">{item.price} د.م.</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  {/* Quantity Selector */}
                  <div className="flex items-center">
                    <button 
                      onClick={() => handleQuantityChange(item.product_id, -1)} 
                      className="bg-gray-200 px-2 py-1 rounded-l hover:bg-gray-300 disabled:opacity-50"
                      disabled={item.quantity <= 1}
                    >
                      -
                    </button>
                    <span className="px-3 py-1 border-t border-b border-gray-200">{item.quantity}</span>
                    <button 
                      onClick={() => handleQuantityChange(item.product_id, 1)} 
                      className="bg-gray-200 px-2 py-1 rounded-r hover:bg-gray-300"
                      // TODO: Optionally disable if quantity exceeds stock
                    >
                      +
                    </button>
                  </div>
                  {/* Item Total */}
                  <p className="font-semibold w-20 text-center">{(item.price * item.quantity).toFixed(2)} د.م.</p>
                  {/* Remove Button */}
                  <button 
                    onClick={() => removeItem(item.product_id)}
                    className="text-red-500 hover:text-red-700 text-sm"
                    title="إزالة المنتج"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Cart Summary & Actions */}
          <div className="flex flex-col md:flex-row justify-between items-start">
            <button 
              onClick={clearCart}
              className="mb-4 md:mb-0 text-gray-500 hover:text-red-600 transition duration-300"
            >
              إفراغ السلة
            </button>
            <div className="w-full md:w-1/3 border p-6 rounded-lg shadow bg-gray-50">
              <h2 className="text-xl font-semibold mb-4">ملخص السلة</h2>
              <div className="flex justify-between mb-2">
                <span>عدد المنتجات:</span>
                <span>{totalItems}</span>
              </div>
              <div className="flex justify-between font-bold text-lg mb-6">
                <span>المجموع الإجمالي:</span>
                <span>{totalPrice.toFixed(2)} د.م.</span>
              </div>
              <Link 
                to="/checkout" 
                className="block w-full text-center bg-purple-600 text-white font-semibold py-3 px-6 rounded hover:bg-purple-700 transition duration-300"
              >
                الانتقال إلى الدفع
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;

