import React from 'react';
// TODO: Import components for featured products, categories, etc.

const HomePage = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-20 mb-12 rounded-lg">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">اكتشف عالم العطور الفاخرة</h1>
          <p className="text-lg mb-8">عطور بتركيز عالي (40% زيت عطري) في قنينات 30 مل أنيقة. جودة تدوم طويلاً.</p>
          {/* TODO: Add Link to shop page */}
          <button className="bg-white text-purple-700 font-semibold py-2 px-6 rounded hover:bg-gray-100 transition duration-300">
            تسوق الآن
          </button>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="mb-12">
        <h2 className="text-3xl font-semibold text-center mb-8">أحدث العطور</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Placeholder for Product Cards */}
          <div className="border p-4 rounded-lg text-center shadow hover:shadow-lg transition duration-300">
            <div className="bg-gray-200 h-48 w-full mb-4 rounded"></div> {/* Image Placeholder */}
            <h3 className="font-semibold mb-2">اسم العطر 1</h3>
            <p className="text-gray-600 mb-4">وصف قصير للعطر...</p>
            <p className="font-bold text-purple-700">50 د.م.</p>
          </div>
          <div className="border p-4 rounded-lg text-center shadow hover:shadow-lg transition duration-300">
            <div className="bg-gray-200 h-48 w-full mb-4 rounded"></div> {/* Image Placeholder */}
            <h3 className="font-semibold mb-2">اسم العطر 2</h3>
            <p className="text-gray-600 mb-4">وصف قصير للعطر...</p>
            <p className="font-bold text-purple-700">55 د.م.</p>
          </div>
          {/* Add more placeholders */} 
        </div>
        {/* TODO: Fetch actual featured products from API */}
      </section>

      {/* Categories Section */}
      <section className="mb-12">
        <h2 className="text-3xl font-semibold text-center mb-8">تصفح حسب الفئة</h2>
        <div className="flex flex-wrap justify-center gap-4">
          {/* Placeholder for Category Links */}
          <span className="bg-gray-200 px-4 py-2 rounded-full cursor-pointer hover:bg-gray-300">رجالي</span>
          <span className="bg-gray-200 px-4 py-2 rounded-full cursor-pointer hover:bg-gray-300">نسائي</span>
          <span className="bg-gray-200 px-4 py-2 rounded-full cursor-pointer hover:bg-gray-300">للجنسين</span>
          {/* TODO: Fetch actual categories from API and create links */} 
        </div>
      </section>

      {/* Special Orders Section */}
      <section className="bg-gray-50 py-12 rounded-lg">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-semibold mb-4">هل تبحث عن عطر خاص؟</h2>
          <p className="text-lg text-gray-700 mb-8">يمكننا مساعدتك في تصميم عطرك الفريد بالتركيز والسعة التي تفضلها. أخبرنا بما تفكر به!</p>
          {/* TODO: Add Link to special orders page */}
          <button className="bg-purple-600 text-white font-semibold py-2 px-6 rounded hover:bg-purple-700 transition duration-300">
            اطلب عطرك الخاص
          </button>
        </div>
      </section>

    </div>
  );
};

export default HomePage;

