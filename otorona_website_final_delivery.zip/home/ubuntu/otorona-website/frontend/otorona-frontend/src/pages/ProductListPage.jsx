import React, { useState, useEffect } from 'react';
import axios from 'axios'; // Assuming axios is installed

// TODO: Import ProductCard component when created
// TODO: Add loading and error states
// TODO: Add filtering/sorting controls

const ProductListPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      setError(null);
      try {
        // TODO: Replace with actual API endpoint from .env or config
        const response = await axios.get('http://localhost:5000/api/products'); 
        setProducts(response.data);
      } catch (err) {
        console.error("Error fetching products:", err);
        setError('Failed to load products. Please try again later.');
      }
      setLoading(false);
    };

    fetchProducts();
  }, []);

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">جميع العطور</h1>
      
      {/* TODO: Add Filtering/Sorting Bar */} 
      <div className="mb-8 p-4 bg-gray-100 rounded-lg">
        <p>خيارات الفلترة والتصنيف ستكون هنا...</p>
      </div>

      {loading && <p className="text-center text-gray-500">جاري تحميل المنتجات...</p>}
      {error && <p className="text-center text-red-500">{error}</p>}

      {!loading && !error && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.length > 0 ? (
            products.map(product => (
              // Placeholder Product Card - Replace with actual ProductCard component
              <div key={product.id} className="border p-4 rounded-lg text-center shadow hover:shadow-lg transition duration-300">
                <div 
                  className="bg-gray-200 h-48 w-full mb-4 rounded bg-cover bg-center"
                  style={{ backgroundImage: `url(${product.image_url || '/placeholder.jpg'})` }} // Use placeholder if no image
                ></div> 
                <h3 className="font-semibold mb-2">{product.name_ar}</h3> {/* Assuming Arabic name */} 
                {/* <p className="text-gray-600 mb-4 text-sm">{product.description_ar?.substring(0, 50)}...</p> */}{/* Optional short description */}
                <p className="font-bold text-purple-700">{product.price} د.م.</p>
                {/* TODO: Add 'Add to Cart' button */} 
                <button className="mt-4 bg-purple-600 text-white text-sm py-1 px-4 rounded hover:bg-purple-700 transition duration-300">
                  أضف للسلة
                </button>
              </div>
            ))
          ) : (
            <p className="col-span-full text-center text-gray-500">لا توجد منتجات لعرضها حالياً.</p>
          )}
        </div>
      )}
      
      {/* TODO: Add Pagination */}
    </div>
  );
};

export default ProductListPage;

