import React from 'react';
import { useLocation, Link } from 'react-router-dom';

const OrderConfirmationPage = () => {
  const location = useLocation();
  const orderDetails = location.state?.order; // Get order details passed from checkout

  if (!orderDetails) {
    // Handle case where user navigates directly without placing order
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-red-600 mb-4">خطأ في عرض تأكيد الطلب</h1>
        <p className="text-gray-600 mb-6">لم يتم العثور على تفاصيل الطلب. ربما قمت بالوصول إلى هذه الصفحة مباشرة.</p>
        <Link to="/" className="bg-purple-600 text-white font-semibold py-2 px-6 rounded hover:bg-purple-700 transition duration-300">
          العودة إلى الرئيسية
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 text-center">
      <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-8 max-w-lg mx-auto" role="alert">
        <strong className="font-bold">تم استلام طلبك بنجاح!</strong>
        <span className="block sm:inline"> شكراً لك على التسوق معنا.</span>
      </div>

      <h1 className="text-2xl font-semibold mb-6">تفاصيل الطلب</h1>
      
      <div className="bg-white p-6 rounded-lg shadow max-w-md mx-auto text-right border">
        <div className="mb-3">
          <span className="font-semibold">رقم الطلب:</span> {orderDetails.orderId}
        </div>
        <div className="mb-3">
          <span className="font-semibold">تاريخ الطلب:</span> {new Date(orderDetails.createdAt).toLocaleDateString('ar-EG')}
        </div>
        <div className="mb-3">
          <span className="font-semibold">المجموع الإجمالي:</span> {orderDetails.totalAmount.toFixed(2)} د.م.
        </div>
        <div className="mb-4">
          <span className="font-semibold">طريقة الدفع:</span> الدفع عند الاستلام
        </div>
        <p className="text-sm text-gray-600">سيتم التواصل معك لتأكيد تفاصيل الشحن. يمكنك تتبع حالة طلبك من صفحة حسابك (إذا قمت بتسجيل الدخول).</p>
      </div>

      <div className="mt-8">
        <Link to="/shop" className="text-purple-600 hover:text-purple-800 font-semibold">
          متابعة التسوق ←
        </Link>
      </div>
    </div>
  );
};

export default OrderConfirmationPage;

